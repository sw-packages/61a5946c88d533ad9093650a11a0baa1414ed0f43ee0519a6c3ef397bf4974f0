<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="lv">
    <dependencies>
        <dependency catalog="qtbase_lv"/>
        <dependency catalog="qtscript_lv"/>
    </dependencies>
</TS>
